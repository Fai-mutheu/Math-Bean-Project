import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        MathOperationsBean mathBean = new MathOperationsBean();
        System.out.println("=== Math Operations Bean ===");
        boolean keepRunning = true;
        while (keepRunning) {
            int num1;
            while (true) {
                System.out.print("\nEnter first number: ");
                if (input.hasNextInt()) {
                    num1 = input.nextInt();
                    break;
                } else {
                    System.out.println("⚠ Invalid input! Please enter a number.");
                    input.next(); // Clear invalid input
                }
            }
            int num2;
            while (true) {
                System.out.print("Enter second number: ");
                if (input.hasNextInt()) {
                    num2 = input.nextInt();
                    break;
                } else {
                    System.out.println("⚠ Invalid input! Please enter a number.");
                    input.next(); // Clear invalid input
                }
            }
            // Set numbers in the bean
            mathBean.setNum1(num1);
            mathBean.setNum2(num2);
            // Show operation menu
            System.out.println("\nChoose an operation:");
            System.out.println("1. Add");
            System.out.println("2. Subtract");
            System.out.println("3. Multiply");
            System.out.println("4. Divide");
            System.out.println("5. Quit");

            int choice;  
            while (true) {
                System.out.print("Enterchoice 1-5:");
                if (input.hasNextInt()) { 
                    choice = input.nextInt();
                    if (choice >= 1 && choice <= 5 ) break;
                else System.out.println("⚠ Invalid choice! Pick 1-5");
                } else {
                    System.out.println("⚠ Invalid input! Please enter a number 1-5");
                    input.next(); // Clear invaid input
                }
            }
            // Perform Operation
            switch (choice) {
                case 1:
                    System.out.println("Result: " + mathBean.add());
                    break;
                case 2:
                    System.out.println("Result: " + mathBean.subtract());
                    break;
                case 3:
                    System.out.println("Result: " + mathBean.multiply());
                    break;
                case 4:
                    System.out.println("Result: " + mathBean.divide());
                    break;
                case 5:
                    keepRunning = false;
                    System.out.println("Goodbye!");
                    break;
            }
        }
        input.close();
    }
}